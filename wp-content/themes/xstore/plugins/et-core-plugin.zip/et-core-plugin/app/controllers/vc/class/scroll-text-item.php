<?php
/**
 * Scroll text item shortcode.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/Controllers/vc/class
 */
if ( class_exists( 'WPBakeryShortCode' ) ) {
	class WPBakeryShortCode_ETHEME_scroll_text_item extends \WPBakeryShortCode {
	}
}