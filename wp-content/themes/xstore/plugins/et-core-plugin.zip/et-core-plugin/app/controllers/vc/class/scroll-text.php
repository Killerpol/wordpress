<?php
/**
 * Scroll text shortcode.
 *
 * @since      1.4.4
 * @package    ETC
 * @subpackage ETC/Controllers/vc/class
 */
if ( class_exists( 'WPBakeryShortCodesContainer' ) ) {
    class WPBakeryShortCode_Etheme_scroll_text extends \WPBakeryShortCodesContainer {
    }
}
